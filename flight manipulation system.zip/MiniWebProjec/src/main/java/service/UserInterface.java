package service;

import model.User;

public interface UserInterface {
	public User addUser(User user);
	public User getUserBYId(long id);
	public User login(String username, String password);
	public void logout();
	public int updateUser(User newUser, long userId);
	public int deleteUser(long userId);
	 public User forgetPass(String username, long userPhone) ;
}
