package model;

import java.util.Date;

public class User {

	private long userId;
	private String userName;
	private String userPassword;
	private String userType;
	private String userAddres;
	private long userPhone;
	private Date userDOB;
	private String geneder;
	
	public User() {
		super();
	}
	public User(long userId, String userNamee, String userPassword, String userType, String userAddres, long userPhone,
			Date userDOB, String geneder) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userType = userType;
		this.userAddres = userAddres;
		this.userPhone = userPhone;
		this.userDOB = userDOB;
		this.geneder = geneder;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userNmae) {
		this.userName = userNmae;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserAddres() {
		return userAddres;
	}
	public void setUserAddres(String userAddres) {
		this.userAddres = userAddres;
	}
	public long getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}
	public Date getUserDOB() {
		return userDOB;
	}
	public void setUserDOB(Date userDob) {
		this.userDOB = userDob;
	}
	public String getGeneder() {
		return geneder;
	}
	public void setGeneder(String geneder) {
		this.geneder = geneder;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userNmae=" + userName + ", userPassword=" + userPassword + ", userType="
				+ userType + ", userAddres=" + userAddres + ", userPhone=" + userPhone + ", userDob=" + userDOB
				+ ", geneder=" + geneder + "]";
	}
	
	
	
}
