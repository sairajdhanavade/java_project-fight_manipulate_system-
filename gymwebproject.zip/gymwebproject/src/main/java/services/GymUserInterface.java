package services;

import model.GymUser;


public interface GymUserInterface {

	public GymUser addUser(GymUser user);
	public GymUser login(String username, long phonenumber);
}
