package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.GymuserImpl;
import model.GymUser;

/**
 * Servlet implementation class UserServelet
 */
@WebServlet("/reg")
public class UserServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String uname=request.getParameter("name");
		int  uage=Integer.parseInt(request.getParameter("age"));
		String ugen=request.getParameter("gen");
		String uaddress=request.getParameter("address");
		long uphone=Long.parseLong(request.getParameter("phone"));
		
		GymUser g=new GymUser();
		g.setUsername(uname);
		g.setAge(uage);
		g.setGender(ugen);
		g.setAddress(uaddress);
		g.setPhonenumber(uphone);
		
		GymuserImpl ser=new GymuserImpl();
		GymUser gu=ser.addUser(g);
		if(gu!=null) {
			out.println("<h3><font color='green'>Welcome"+" "+g.getUsername()+" "+"</font></h3>");
			out.println("<a href='gymHome.jsp'>Home</a>");
		}else {
			response.sendRedirect("error.jsp");
		}
		
	}

}
