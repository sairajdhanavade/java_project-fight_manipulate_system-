package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.GymUser;

import services.GymUserInterface;
import utility.DBUtil;

public class GymuserImpl implements GymUserInterface {

	@Override
	public GymUser addUser(GymUser user) {
		int status=0;
		try(Connection con=DBUtil.getConnect();){
			String insert_query="insert into user_details(user_name, user_age, user_gender, user_address, user_phone) values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(insert_query);
			ps.setString(1, user.getUsername());
			ps.setInt(2, user.getAge());
			ps.setString(3, user.getGender());
			ps.setString(4, user.getAddress());
			ps.setLong(5, user.getPhonenumber());
			status=ps.executeUpdate();
		}catch(Exception e) {
			System.out.println(e);
		}
		if(status>0) {
			return user;
		}
		return null;
	}

	@Override
	public GymUser login(String username, long phonenumber) {
		try(Connection con=DBUtil.getConnect();){
			String loginQuery=
					"select * from user_details where user_name=? and user_phone=?";
			PreparedStatement ps=con.prepareStatement(loginQuery);
			ps.setString(1, username);
			ps.setLong(2, phonenumber);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				long uid = rs.getLong(1);
				String un = rs.getString(2);
				int age = rs.getInt(3);
				String gen = rs.getString(4);
				String uadd = rs.getString(5);
				long ph = rs.getLong(6);
				
				
				
			
				
				//Creating obj of user and passing values using user constructor 
				GymUser user = new GymUser(un, age, gen, uadd, ph);//String username, int age, String gender, String address, long phonenumber
				return user;
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
