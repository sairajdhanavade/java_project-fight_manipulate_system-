package model;

public class GymUser {
 private String username;
 private int age;
 private String gender;
 private String address;
 private long phonenumber;
public GymUser() {
	super();
}
public GymUser(String username, int age, String gender, String address, long phonenumber) {
	super();
	this.username = username;
	this.age = age;
	this.gender = gender;
	this.address = address;
	this.phonenumber = phonenumber;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public long getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(long phonenumber) {
	this.phonenumber = phonenumber;
}
@Override
public String toString() {
	return "GymUser [username=" + username + ", age=" + age + ", gender=" + gender + ", address=" + address
			+ ", phonenumber=" + phonenumber + "]";
}
 
}

